package toys;

public class ActionFigure extends Doll{
    protected ActionFigure(String name, int age, String speak){
        super(0,name, Color.RED, age, speak);
    }

    public int getEnergyLevel(){
        return 0;
    }

    @Override
    protected void specialPlay(int time) {

    }

    @Override
    public String toString() {
        return null;
    }
}
