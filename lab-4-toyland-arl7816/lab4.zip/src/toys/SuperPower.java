package toys;

/**
 * An enumerated type for superhero powers
 * @author Alex Lee
 * */

public enum SuperPower{
    FLIGHT,
    STRENGTH,
    INVINCIBILITY,
    LASERBEAM,
    TELEPORTATION
}
